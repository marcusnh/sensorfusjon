#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Oct 12 14:07:05 2020

@author: marcusnotohansen
"""
import numpy as np
p10=0.9
a = np.array((p10,(1-p10)/2,(1-p10)/2))
print(a)